from django.contrib import admin
from .models import Category, Complaint, Feedback, Jobs, Login, Query, Register
# Register your models here.

admin.site.register(Login)
admin.site.register(Register)
admin.site.register(Jobs)
admin.site.register(Feedback)
admin.site.register(Query)
admin.site.register(Category)
admin.site.register(Complaint)