from django.db import models
from django.utils  import timezone


# Create your models here.
class Login(models.Model):
    email=models.CharField(max_length=40)
    password=models.CharField(max_length=40)
    role=models.CharField(max_length=40)
    
class Register(models.Model):
    name=models.CharField(max_length=40)
    email=models.CharField(max_length=40)
    password=models.CharField(max_length=40)
    mobile_no=models.IntegerField()
    place=models.CharField(max_length=40)
    role=models.CharField(max_length=40)
    login_id=models.OneToOneField(Login,on_delete=models.CASCADE)
    


class Category(models.Model):
    category_name=models.CharField(max_length=40)


    
class Jobs(models.Model):
    job_name=models.CharField(max_length=40)
    location=models.CharField(max_length=40)
    contact_no=models.IntegerField()
    salary=models.IntegerField()
    vacancies=models.IntegerField()
    skills=models.CharField(max_length=40)
    category_id=models.ForeignKey(Category,on_delete=models.CASCADE,null=True,blank=True)
    date=models.DateTimeField(default=timezone.now,auto_created=True)
    
class Feedback(models.Model):
    user_id=models.CharField(max_length=40)
    jobs_id=models.CharField(max_length=40)
    description=models.CharField(max_length=100)
    date=models.DateTimeField(default=timezone.now,auto_created=True)
    
    
class Query(models.Model):
    user_id=models.CharField(max_length=40)
    jobs_id=models.CharField(max_length=40)
    query=models.CharField(max_length=100)
    reply=models.CharField(max_length=100,default='',blank=True,null=True)
    date=models.DateTimeField(default=timezone.now,auto_created=True)
    
class Complaint(models.Model):
    user_id=models.CharField(max_length=40)
    jobs_id=models.CharField(max_length=40)
    complaint=models.CharField(max_length=100)
    reply=models.CharField(max_length=100,default='',blank=True,null=True)
    date=models.DateTimeField(default=timezone.now,auto_created=True)