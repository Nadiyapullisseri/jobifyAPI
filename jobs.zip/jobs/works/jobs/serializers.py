


from dataclasses import fields
from importlib.metadata import MetadataPathFinder
from pyexpat import model
from rest_framework import serializers
from .models import Category, Complaint, Feedback, Jobs, Login, Query, Register


class LoginSerializer(serializers.ModelSerializer):
    class Meta:
        model=Login
        fields='__all__'
        
class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model=Register
        fields='__all__'
        
class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model=Jobs
        fields='__all__'


class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model=Feedback
        fields='__all__'
        
class QuerySerializer(serializers.ModelSerializer):
    class Meta:
        model=Query
        fields='__all__'
    
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model=Category
        fields='__all__'

class ComplaintSerializer(serializers.ModelSerializer):
    class Meta:
        model=Complaint
        fields='__all__'