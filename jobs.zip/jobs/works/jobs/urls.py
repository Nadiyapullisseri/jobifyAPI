from django.urls import path
from . import views

urlpatterns=[
    path('',views.index),
    path('user-register/',views.user_register_view.as_view()),
    path('user-login/',views.user_login_view.as_view()),
    path('user-all-view/',views.user_all_view.as_view()),
    path('user-update/<int:id>',views.user_update_view.as_view()),
    path('user-delete/<int:id>',views.user_delete_view.as_view()),
    path('change-password/<int:id>',views.change_password_view.as_view()),
    path('jobs-add/',views.jobs_add_view.as_view()),
    path('jobs-view/',views.jobs_view.as_view()),
    path('jobs-update/<int:id>',views.jobs_update.as_view()),
    path('jobs-delete/<int:id>',views.jobs_delete.as_view()),
    path('jobs-search/',views.jobs_search.as_view()),
    path('feedback-add/',views.feedback_add.as_view()),
    path('feedback-view/',views.feedback_view.as_view()),
    path('feedback-view-based-on-jobs/<int:jobs_id>',views.feedback_view_based_on_jobs.as_view()),
    path('feedback-delete/<int:user_id>/<int:id>',views.feedback_delete.as_view()),
    path('query-add/',views.query_add.as_view()),
    path('query-view/',views.query_view.as_view()),
    path('query-reply/<int:id>',views.query_reply.as_view()),
    path('category-add/',views.category_add.as_view()),
    path('category-view/',views.category_view.as_view()),
    path('complaint-add/',views.complaint_add.as_view()),
    path('complaint-reply/<int:id>',views.complaint_reply.as_view()),
    path('complaints-view/',views.complaints_view.as_view()),
    ]