from functools import partial
from urllib import response
from django.shortcuts import render
from django.http import HttpResponse
from rest_framework .generics import GenericAPIView
from .serializers import CategorySerializer, ComplaintSerializer, FeedbackSerializer, JobSerializer, LoginSerializer, QuerySerializer, RegisterSerializer
from rest_framework.response import Response
from rest_framework import status
from . models import Category, Complaint, Feedback, Jobs, Login, Query, Register
from django.utils import timezone
from django.db.models import Q

# Create your views here.
def index(request):
    return HttpResponse("homepage")

class user_register_view(GenericAPIView):
    serializer_class=RegisterSerializer
    def post(self,request):
        name=request.data.get('name')
        email=request.data.get('email')
        password=request.data.get('password')
        mobile_no=request.data.get('mobile_no')
        place=request.data.get('place')
        role='user'
        login_id=""
        if not name or not email or not password or not mobile_no or not place:
            return Response({'message':'all fields are requred'},status=status.HTTP_400_BAD_REQUEST)
        if Register.objects.filter(name=name).exists():
            return Response({'message':'name already exist'},status=status.HTTP_400_BAD_REQUEST)
        if Register.objects.filter(mobile_no=mobile_no).exists():
            return Response({'message':'mobile_no already exist'},status=status.HTTP_400_BAD_REQUEST)
        
        login_serializer=LoginSerializer(data={'email':email,
                                               'password':password,
                                               'role':role})
        if login_serializer.is_valid():
            l=login_serializer.save()
            login_id=l.id
        else:
            return Response({'message':'login failed'},status=status.HTTP_400_BAD_REQUEST)
        register_serializer=RegisterSerializer(data={'name':name,
                                                     'email':email,
                                                     'password':password,
                                                     'mobile_no':mobile_no,
                                                     'place':place,
                                                     'role':role,
                                                     'login_id':login_id})
        if register_serializer.is_valid():
            register_serializer.save()
            return Response({'message':'registration sucessfull'},status=status.HTTP_200_OK)
        else:
            return Response({'message':'registration failed'},status=status.HTTP_400_BAD_REQUEST)
        
        
class user_login_view(GenericAPIView):
    serializer_class=LoginSerializer
    def post(self,request):
        email=request.data.get('email')
        password=request.data.get('password')
        logins=Login.objects.filter(email=email,password=password)
        if (logins.count()>0):
            login_serializer=LoginSerializer(logins,many=True)
            for i in login_serializer.data:
                login_id=i['id']
                role=i['role']
                register_data=Register.objects.filter(login_id=login_id).values()
                for i in register_data:
                    name=i['name']
            return Response({'data':{'login_id':login_id,'name':name,'email':email,'password':password},'success':1,'message':'login successfull'})
        else:
            return Response({'message':'login failed'},status=status.HTTP_400_BAD_REQUEST)
        
        
class user_all_view(GenericAPIView):
    serializer_class=RegisterSerializer
    def get(self,request):
        users=Register.objects.all()
        if users.count()>0:
            register_serializer=RegisterSerializer(users,many=True)
            return Response({'data':register_serializer.data,'message':'get the all data'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
        
class user_update_view(GenericAPIView):
    serializer_class=RegisterSerializer
    def put(self,request,id):
        users=Register.objects.get(pk=id)
        update_serializer=RegisterSerializer(instance=users,data=request.data,partial=True)
        if update_serializer.is_valid():
            update_serializer.save()
            return Response({'message':'updataion successfull'},status=status.HTTP_200_OK)
        else:
            return Response({'message':'some error in updation'},status=status.HTTP_400_BAD_REQUEST)
        
        
class user_delete_view(GenericAPIView):
    serializer_class=RegisterSerializer
    def delete(self,request,id):
        user=Register.objects.get(pk=id)
        user.delete()
        return Response({'message':'deleted successfully'},status=status.HTTP_200_OK) 
    
    
class change_password_view(GenericAPIView):
    serializer_class=LoginSerializer 
    def put(self,request,id):
        try:
            user=Login.objects.get(pk=id)
        except Login.DoesNotExist:
            return Response({'message':'user not found'},status=status.HTTP_400_BAD_REQUEST)
        serializer=self.serializer_class(user,data=request.data,partial=True)
        if serializer.is_valid():
            new_password=serializer.validated_data.get('password')
            print(new_password)
            if new_password:
                user.password=new_password
                user.save()
                return Response({'message':'successfully update new password'},status=status.HTTP_200_OK)
            return Response({'message':'no password provided'},status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'message':'password change failed'},status=status.HTTP_400_BAD_REQUEST)      
        
        
class jobs_add_view(GenericAPIView):
    serializer_class=JobSerializer
    def post(self,request):
        job_name=request.data.get('job_name')
        location=request.data.get('location') 
        contact_no=request.data.get('contact_no')
        salary=request.data.get('salary')
        vacancies=request.data.get('vacancies')
        skills=request.data.get('skills')
        category_id=request.data.get('category_id')
        if not job_name or not location or not contact_no or not salary or not vacancies or not skills or not category_id:
            return Response({'message':'all fields are requerd'},status=status.HTTP_400_BAD_REQUEST)
        try:
            category=Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return Response({'message':'invalid category id'},status=status.HTTP_400_BAD_REQUEST)
        date=timezone.now().isoformat()
        jobs_seralizer=JobSerializer(data={'job_name':job_name,
                                           'location':location,
                                           'contact_no':contact_no,
                                           'salary':salary,
                                           'vacancies':vacancies,
                                           'skills':skills,
                                           'category_id':category_id,
                                           'date':date})
        if jobs_seralizer.is_valid():
            jobs_seralizer.save()
            return Response({'message':'jobs added successfully'},status=status.HTTP_200_OK)
        else:
            return Response(jobs_seralizer.errors,status=status.HTTP_400_BAD_REQUEST)
        
        
class jobs_view(GenericAPIView):
    serializer_class=JobSerializer
    def get(self,request):
        jobs=Jobs.objects.all()
        if jobs.count()>0:
            jobs_serializer=JobSerializer(jobs,many=True)
            return Response({'data':jobs_serializer.data,'message':'successfully get all jobs'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        

class jobs_update(GenericAPIView):
    serializer_class=JobSerializer
    def put(self,request,id):
        jobs=Jobs.objects.get(pk=id)
        job_serializer=JobSerializer(instance=jobs,data=request.data,partial=True)
        if job_serializer.is_valid():
            job_serializer.save()
            return Response({'message':'updation successfull'},status=status.HTTP_200_OK)
        else:
            return Response({'message':'some error in updation'},status=status.HTTP_400_BAD_REQUEST)
        

class jobs_delete(GenericAPIView):
    serializer_class=JobSerializer
    def delete(self,request,id):
        jobs=Jobs.objects.get(pk=id)
        jobs.delete()
        return Response({'message':'deleted successfully'},status=status.HTTP_200_OK)
    
class jobs_search(GenericAPIView):
    serializer_class=JobSerializer
    def post(self,request):
        search_query=request.data.get('search_query','')
        if search_query:
            jobs=Jobs.objects.filter(Q(job_name__icontains=search_query)|Q(location__icontains=search_query)|Q(category_id__category_name__icontains=search_query))
            if not jobs.exists():
                return Response({'message':'jobs not found'},status=status.HTTP_400_BAD_REQUEST)
            job_serializer=self.serializer_class(jobs,many=True)
            return Response({'data':job_serializer.data,'message':'jobs successfully fetch'},status=status.HTTP_200_OK)
        return Response({'message':'no search query provided'},status=status.HTTP_400_BAD_REQUEST)
    
    
class feedback_add(GenericAPIView):
    serializer_class=FeedbackSerializer
    def post(self,request):
        user_id=request.data.get('user_id')
        jobs_id=request.data.get('jobs_id')
        description=request.data.get('description')
        if not user_id or not jobs_id or not description:
            return Response({'message':'all field are requerd'},status=status.HTTP_400_BAD_REQUEST)
        date=timezone.now().isoformat()
        feedback_serializer=FeedbackSerializer(data={'user_id':user_id,
                                                     'jobs_id':jobs_id,
                                                     'description':description,
                                                     'date':date})
        if feedback_serializer.is_valid():
            feedback_serializer.save()
            return Response({'message':'feedback added successfully'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
        
        
class feedback_view(GenericAPIView):
    serializer_class=FeedbackSerializer
    def get(self,request):
        feedback=Feedback.objects.all()
        if feedback.count()>0:
            feedback_serializer=FeedbackSerializer(feedback,many=True)
            return Response({'data':feedback_serializer.data,'message':'successfully get all data'},status=status.HTTP_200_OK)
        
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
        
class feedback_view_based_on_jobs(GenericAPIView):
    def get(self,request,jobs_id):
        feedback=Feedback.objects.filter(jobs_id=jobs_id)
        if feedback.exists():
            feedback_serializer=FeedbackSerializer(feedback,many=True)
            return Response({'data':feedback_serializer.data,'message':'successfully get all data'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
class feedback_delete(GenericAPIView):
    serializer_class=FeedbackSerializer
    def delete(self,request,user_id,id):
        feedback=Feedback.objects.get(user_id=user_id,pk=id)
        feedback.delete()
        return Response({'message':'deleted successfully'},status=status.HTTP_200_OK)
    

class query_add(GenericAPIView):
    def post(self,request):
        user_id=request.data.get('user_id')
        jobs_id=request.data.get('jobs_id')
        query=request.data.get('query')
        reply=request.data.get('reply','')
        if not user_id or not jobs_id or not query:
            return Response({'message':'all fields are requrd'},status=status.HTTP_400_BAD_REQUEST)
        date=timezone.now().isoformat()
        query_serializer=QuerySerializer(data={'user_id':user_id,
                                               'jobs_id':jobs_id,
                                               'query':query,
                                               'reply':reply,
                                               'date':date})
        if query_serializer.is_valid():
            query_serializer.save()
            return Response({'message':'query added successfully'},status=status.HTTP_200_OK)
        else:
            return Response(query_serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        
        
class query_view(GenericAPIView):
    serializer_class=QuerySerializer
    def get(self,request):
        queries=Query.objects.all()
        if queries.count()>0:
            query_serializer=QuerySerializer(queries,many=True)
            return Response({'data':query_serializer.data,'message':'get all queries'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        

class query_reply(GenericAPIView):
    serializer_class=QuerySerializer
    def put(self,request,id):
        reply=Query.objects.get(pk=id)
        query_serializer=QuerySerializer(instance=reply,data=request.data,partial=True)
        if query_serializer.is_valid():
            query_serializer.save()
            return Response({'message':'successfully add the reply'},status=status.HTTP_200_OK)
        else:
            return Response(query_serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        
        
class category_add(GenericAPIView):
    serializer_class=CategorySerializer
    def post(self,request):
        category_name=request.data.get('category_name')
        if not category_name:
            return Response({'message':'category_name must be requrd'},status=status.HTTP_400_BAD_REQUEST)
        if Category.objects.filter(category_name=category_name).exists():
            return Response({'message':'duplicate names are not allowed'})
        category_serializer=CategorySerializer(data={'category_name':category_name})
        if category_serializer.is_valid():
            category_serializer.save()
            return Response({'message':'category successfully added'},status=status.HTTP_200_OK)
        else:
            return Response(category_serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        
class category_view(GenericAPIView):
    serializer_class=CategorySerializer
    def get(self,request):
        categories=Category.objects.all()
        if categories.count()>0:
            category_serializer=CategorySerializer(categories,many=True)
            return Response({'data':category_serializer.data,'message':'successfully get all data'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
        
class complaint_add(GenericAPIView):
    serializer_class=ComplaintSerializer
    def post(self,request):
        user_id=request.data.get('user_id')
        jobs_id=request.data.get('jobs_id')
        complaint=request.data.get('complaint')
        reply=request.data.get('reply','')
        if not user_id or not jobs_id or not complaint:
            return Response({'message':'all fields are requerd'},status=status.HTTP_400_BAD_REQUEST)
        date=timezone.now().isoformat()
        complaint_serializer=ComplaintSerializer(data={'user_id':user_id,
                                                       'jobs_id':jobs_id,
                                                       'complaint':complaint,
                                                       'reply':reply,
                                                       'date':date})
        if complaint_serializer.is_valid():
            complaint_serializer.save()
            return Response({'message':'successfully add complaint'},status=status.HTTP_200_OK)
        else:
            return Response(complaint_serializer.errors,status=status.HTTP_400_BAD_REQUEST)

class complaint_reply(GenericAPIView):
    def put(self,request,id):
        complaints=Complaint.objects.get(pk=id)
        complaint_serializer=ComplaintSerializer(instance=complaints,data=request.data,partial=True)
        if complaint_serializer.is_valid():
            complaint_serializer.save()
            return Response({'message':'successfully add the reply'},status=status.HTTP_200_OK)
        else:
            return Response(complaint_serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        
class complaints_view(GenericAPIView):
    def get(self,request):
        complaints=Complaint.objects.all()
        if complaints.exists():
            complaint_serializer=ComplaintSerializer(complaints,many=True)
            return Response({'data':complaint_serializer.data,'message':'successfully get all complaints'},status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)